package com.example.simplecalculator

import android.os.Bundle
import android.util.Log
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.*

class MainActivity : ComponentActivity() {

    private val TAG = "CalculatorLifecycle"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate called")
        enableEdgeToEdge()
        setContent {
            CalculatorScreen()
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart called")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume called")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause called")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop called")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy called")
    }
}

// ---------- COLOR PALETTE ----------
private val colorBackground = Color(0xFF10082E)
private val colorPanel = Color(0xFF1B1140)
private val colorSciPanel = Color(0xFF241654)
private val colorNumberBtn = Color(0xFF2D1B69)
private val colorOperatorBtn = Color(0xFF00D4D4)
private val colorActionBtn = Color(0xFFFF5E78)
private val colorSciBtn = Color(0xFF7B2CBF)
private val colorTextLight = Color(0xFFFFFFFF)
private val colorTextMuted = Color(0xFF9D8FD4)
private val colorAccentText = Color(0xFF00FFE5)

@Composable
fun CalculatorScreen() {
    var expression by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("0") }
    var isDegreeMode by remember { mutableStateOf(true) }
    var sciVisible by remember { mutableStateOf(false) }

    fun append(value: String) {
        expression += value
    }

    fun deleteLast() {
        if (expression.isNotEmpty()) expression = expression.dropLast(1)
    }

    fun clearAll() {
        expression = ""
        result = "0"
    }

    fun formatResult(value: Double): String {
        return if (value == value.toLong().toDouble()) value.toLong().toString() else value.toString()
    }

    fun applyUnary(function: String) {
        val value = expression.toDoubleOrNull()
        if (value == null) { result = "Error"; return }
        val angle = if (isDegreeMode) Math.toRadians(value) else value
        val r = when (function) {
            "sin" -> sin(angle)
            "cos" -> cos(angle)
            "tan" -> tan(angle)
            "sinh" -> sinh(value)
            "cosh" -> cosh(value)
            "tanh" -> tanh(value)
            "sqrt" -> sqrt(value)
            "log" -> log10(value)
            else -> Double.NaN
        }
        expression = formatResult(r)
        result = formatResult(r)
    }

    fun applyFactorial() {
        val value = expression.toIntOrNull()
        if (value == null || value < 0) { result = "Error"; return }
        var r = 1.0
        for (i in 2..value) r *= i
        expression = formatResult(r)
        result = formatResult(r)
    }

    fun applyPercent() {
        val value = expression.toDoubleOrNull()
        if (value == null) { result = "Error"; return }
        val r = value / 100.0
        expression = formatResult(r)
        result = formatResult(r)
    }

    fun applyInverse() {
        val value = expression.toDoubleOrNull()
        if (value == null || value == 0.0) { result = "Error"; return }
        val r = 1.0 / value
        expression = formatResult(r)
        result = formatResult(r)
    }

    fun calculate() {
        if (expression.isEmpty()) return
        try {
            val r = evaluateExpression(expression)
            result = formatResult(r)
        } catch (e: Exception) {
            result = "Error"
            Log.e("CalculatorLifecycle", "Calculation error: ${e.message}")
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = colorBackground) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "⚡ NOVACALC",
                color = colorAccentText,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "scientific edition",
                color = colorTextMuted,
                fontSize = 12.sp,
                modifier = Modifier.padding(bottom = 20.dp)
            )

            // Display panel
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(colorPanel, RoundedCornerShape(24.dp))
                    .padding(20.dp)
            ) {
                Text(
                    text = expression,
                    color = colorTextMuted,
                    fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.End
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = result,
                    color = colorTextLight,
                    fontSize = 42.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = androidx.compose.ui.text.style.TextAlign.End
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Scientific mode toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(colorPanel, RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "SCIENTIFIC MODE", color = colorAccentText, fontSize = 13.sp)
                Switch(checked = sciVisible, onCheckedChange = { sciVisible = it })
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (sciVisible) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(colorSciPanel, RoundedCornerShape(20.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "FUNCTIONS",
                        color = colorTextMuted,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(start = 8.dp, bottom = 8.dp)
                    )

                    CalcRow(listOf(
                        "sin" to { applyUnary("sin") },
                        "cos" to { applyUnary("cos") },
                        "tan" to { applyUnary("tan") },
                        "DEG" to { isDegreeMode = !isDegreeMode; result = if (isDegreeMode) "DEG mode" else "RAD mode" }
                    ), colorSciBtn)

                    CalcRow(listOf(
                        "sinh" to { applyUnary("sinh") },
                        "cosh" to { applyUnary("cosh") },
                        "tanh" to { applyUnary("tanh") },
                        "π" to { append(PI.toString()) }
                    ), colorSciBtn)

                    CalcRow(listOf(
                        "√" to { applyUnary("sqrt") },
                        "x^y" to { append("^") },
                        "x!" to { applyFactorial() },
                        "log" to { applyUnary("log") }
                    ), colorSciBtn)

                    CalcRow(listOf(
                        "nPr" to { append("P") },
                        "nCr" to { append("C") },
                        "%" to { applyPercent() },
                        "1/x" to { applyInverse() }
                    ), colorSciBtn)
                }
                Spacer(modifier = Modifier.height(16.dp))
            }

            // Standard keypad
            CalcRow(listOf(
                "C" to { clearAll() },
                "(" to { append("(") },
                ")" to { append(")") },
                "÷" to { append("/") }
            ), colorNumberBtn, mapOf("C" to colorActionBtn, "÷" to colorOperatorBtn))

            CalcRow(listOf(
                "7" to { append("7") },
                "8" to { append("8") },
                "9" to { append("9") },
                "×" to { append("*") }
            ), colorNumberBtn, mapOf("×" to colorOperatorBtn))

            CalcRow(listOf(
                "4" to { append("4") },
                "5" to { append("5") },
                "6" to { append("6") },
                "−" to { append("-") }
            ), colorNumberBtn, mapOf("−" to colorOperatorBtn))

            CalcRow(listOf(
                "1" to { append("1") },
                "2" to { append("2") },
                "3" to { append("3") },
                "+" to { append("+") }
            ), colorNumberBtn, mapOf("+" to colorOperatorBtn))

            CalcRow(listOf(
                "." to { append(".") },
                "0" to { append("0") },
                "⌫" to { deleteLast() },
                "=" to { calculate() }
            ), colorNumberBtn, mapOf("=" to colorActionBtn))

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun CalcRow(
    buttons: List<Pair<String, () -> Unit>>,
    defaultColor: Color,
    overrides: Map<String, Color> = emptyMap()
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        for ((label, action) in buttons) {
            val btnColor = overrides[label] ?: defaultColor
            val isLight = btnColor == colorOperatorBtn || btnColor == colorActionBtn
            Button(
                onClick = action,
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = btnColor,
                    contentColor = if (isLight) Color.Black else Color.White
                )
            ) {
                Text(text = label, fontSize = 16.sp)
            }
        }
    }
}

// ---------- EXPRESSION EVALUATOR ----------

fun evaluateExpression(expr: String): Double {
    val sanitized = expr.replace(" ", "")
    val tokens = tokenize(sanitized)
    val (value, _) = parseExpression(tokens, 0)
    return value
}

fun tokenize(expr: String): List<String> {
    val tokens = mutableListOf<String>()
    var i = 0
    while (i < expr.length) {
        val c = expr[i]
        when {
            c.isDigit() || c == '.' -> {
                val sb = StringBuilder()
                while (i < expr.length && (expr[i].isDigit() || expr[i] == '.')) {
                    sb.append(expr[i]); i++
                }
                tokens.add(sb.toString())
            }
            c == '+' || c == '-' || c == '*' || c == '/' || c == '(' || c == ')' || c == '^' || c == 'P' || c == 'C' -> {
                tokens.add(c.toString()); i++
            }
            else -> i++
        }
    }
    return tokens
}

fun parseExpression(tokens: List<String>, startPos: Int): Pair<Double, Int> {
    var pos = startPos
    var (left, newPos) = parseTerm(tokens, pos)
    pos = newPos
    while (pos < tokens.size && (tokens[pos] == "+" || tokens[pos] == "-")) {
        val op = tokens[pos]; pos++
        val (right, p2) = parseTerm(tokens, pos)
        pos = p2
        left = if (op == "+") left + right else left - right
    }
    return Pair(left, pos)
}

fun parseTerm(tokens: List<String>, startPos: Int): Pair<Double, Int> {
    var pos = startPos
    var (left, newPos) = parseFactor(tokens, pos)
    pos = newPos
    while (pos < tokens.size && (tokens[pos] == "*" || tokens[pos] == "/" || tokens[pos] == "P" || tokens[pos] == "C")) {
        val op = tokens[pos]; pos++
        val (right, p2) = parseFactor(tokens, pos)
        pos = p2
        left = when (op) {
            "*" -> left * right
            "/" -> left / right
            "P" -> permutation(left.toInt(), right.toInt())
            "C" -> combination(left.toInt(), right.toInt())
            else -> left
        }
    }
    return Pair(left, pos)
}

fun parseFactor(tokens: List<String>, startPos: Int): Pair<Double, Int> {
    var pos = startPos
    var (base, newPos) = parseBase(tokens, pos)
    pos = newPos
    if (pos < tokens.size && tokens[pos] == "^") {
        pos++
        val (exponent, p2) = parseFactor(tokens, pos)
        pos = p2
        base = base.pow(exponent)
    }
    return Pair(base, pos)
}

fun parseBase(tokens: List<String>, startPos: Int): Pair<Double, Int> {
    var pos = startPos
    if (pos < tokens.size && tokens[pos] == "(") {
        pos++
        val (value, p2) = parseExpression(tokens, pos)
        pos = p2
        if (pos < tokens.size && tokens[pos] == ")") pos++
        return Pair(value, pos)
    }
    if (pos < tokens.size && tokens[pos] == "-") {
        pos++
        val (value, p2) = parseBase(tokens, pos)
        return Pair(-value, p2)
    }
    val value = tokens[pos].toDoubleOrNull() ?: 0.0
    return Pair(value, pos + 1)
}
fun permutation(n: Int, r: Int): Double {
    if (r > n) return 0.0
    var result = 1.0
    for (i in 0 until r) result *= (n - i)
    return result
}

fun combination(n: Int, r: Int): Double {
        if (r > n) return 0.0
        return permutation(n, r) / factorial(r)
}
fun factorial(n: Int): Double {
    var result = 1.0
    for (i in 2..n) result *= i
    return result
}